import os
import cv2
import time
import pickle
import threading
import numpy as np
import requests
from collections import deque
from ultralytics import YOLO
from insightface.app import FaceAnalysis
import onnxruntime as ort
import torch
import csv

ort.preload_dlls()
LOG_PATH = "pad_scores.csv"
# ================= CONFIG =================
CAMERA_ID = 0

ANTI_REAL = 1
ANTI_FAKE = 0

FIREBASE_URL = "https://hptproject-default-rtdb.asia-southeast1.firebasedatabase.app"

ANTI_WINDOW = 50
FACE_WINDOW = 30

REAL_CONF_TH = 0.6
FAKE_CONF_TH = 0.6

FAKE_RATIO_TH_ANTI = 0.6
REAL_RATIO_TH_ANTI = 0.6
SUSPICIOUS_RATIO_TH = 0.3   # ⭐ MỚI: ngưỡng nghi ngờ

class FaceIDEngine:
    def __init__(self, cam_id=CAMERA_ID):
            # --- Paths (đúng theo vị trí file faceid_stream.py) ---
        base_dir = os.path.dirname(os.path.abspath(__file__))
        anti_model_path = os.path.join(base_dir, "phat.pt")
        face_db_path = os.path.join(base_dir, "face_db.pkl")

        # --- PAD LOG (tạo 1 lần, tạo sớm để chắc chắn có file) ---
        self.LOG_PATH = os.path.join(base_dir, "pad_scores.csv")
        self._log_f = open(self.LOG_PATH, "a", newline="", encoding="utf-8")
        self._log_w = csv.writer(self._log_f)
        if self._log_f.tell() == 0:
            self._log_w.writerow(["ts", "score_bona", "real_ratio", "fake_ratio", "sus_ratio", "state_end", "gt_label", "pai"])
        print("USING faceid_stream from:", os.path.abspath(__file__))
        print("PAD log ->", self.LOG_PATH)

        # --- Camera ---
        self.cap = cv2.VideoCapture(cam_id)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera id={cam_id}")

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        # (tuỳ chọn) giảm lag do buffer
        try:
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass

        # --- GPU requirement (KHÔNG fallback CPU) ---
        assert torch.cuda.is_available(), "Torch CUDA NOT available -> YOLO sẽ chạy CPU!"
        # preload DLLs (Windows) nếu có
        if hasattr(ort, "preload_dlls"):
            ort.preload_dlls()
        assert "CUDAExecutionProvider" in ort.get_available_providers(), \
            "ONNXRuntime không có CUDA EP -> InsightFace sẽ chạy CPU!"

        # --- Models (GPU) ---
        self.anti_model = YOLO(anti_model_path)

        self.arcface = FaceAnalysis(
            name="buffalo_l",
            providers=["CUDAExecutionProvider", "CPUExecutionProvider"]
        )
        self.arcface.prepare(ctx_id=0)

        # --- Load face DB ---
        with open(face_db_path, "rb") as f:
            self.face_db = pickle.load(f)

        # --- State machine ---
        self.state = "IDLE"

        # ================= WINDOWS =================
        self.fake_frames = deque(maxlen=ANTI_WINDOW)
        self.real_frames = deque(maxlen=ANTI_WINDOW)
        self.suspicious_frames = deque(maxlen=ANTI_WINDOW)
        self.face_frames = deque(maxlen=FACE_WINDOW)

        self.last_name = None
        self.show_name_until = 0
        self.fake_cooldown_until = 0
        self.faceid_fake_since = None
        self.pending_attendance = None

        # --- Debug info ---
        print("Torch:", torch.__version__)
        print("Torch CUDA:", torch.version.cuda)
        print("GPU:", torch.cuda.get_device_name(0))
        print("ORT providers:", ort.get_available_providers())

        # Ultralytics YOLO thường load weights trên CPU, GPU dùng khi predict(device=0)
        try:
            yolo_dev = next(self.anti_model.model.parameters()).device
            print("YOLO weights device (init):", yolo_dev)
        except Exception:
            pass


    # ================= ROI =================
    def get_roi(self, frame):
        h, w = frame.shape[:2]
        box = int(min(w, h) * 0.45)
        cx, cy = w // 2, h // 2
        x1, y1 = cx - box // 2, cy - box // 2
        x2, y2 = cx + box // 2, cy + box // 2
        return frame[y1:y2, x1:x2], (x1, y1, x2, y2)

    # ================= FACEID =================
    def recognize(self, roi):
        faces = self.arcface.get(roi)
        if not faces:
            return None

        emb = faces[0].embedding
        emb = emb / np.linalg.norm(emb)

        names = self.face_db["names"]
        embs = self.face_db["embeddings"]

        best_name, best_sim = None, 0
        for i in range(len(names)):
            sim = np.dot(emb, embs[i])
            if sim > best_sim:
                best_sim, best_name = sim, names[i]

        return best_name if best_sim > 0.45 else None

    # ================= RESET =================
    def reset(self):
        self.state = "IDLE"
        self.fake_frames.clear()
        self.real_frames.clear()
        self.suspicious_frames.clear()
        self.face_frames.clear()
    # ===========================================
    def log_presentation(self, score_bona, real_ratio, fake_ratio, sus_ratio, state_end, gt_label="", pai=""):
        self._log_w.writerow([time.time(), score_bona, real_ratio, fake_ratio, sus_ratio, state_end, gt_label, pai])
        self._log_f.flush()

    # ================= PROCESS =================
    def process(self, frame):
        now = time.time()
        roi, (x1, y1, x2, y2) = self.get_roi(frame)

        # ================= FAKE COOLDOWN =================
        if now < self.fake_cooldown_until:
            cv2.putText(frame, "FAKE DETECTED - REMOVE SPOOF",
                        (20, 70), cv2.FONT_HERSHEY_SIMPLEX,
                        0.7, (0, 0, 255), 2)
            return frame

        # ================= ANTI-SPOOF =================
        res = self.anti_model.predict(frame, conf=0.3, device=0, verbose=False)[0]


        real_this_frame = False
        fake_this_frame = False
        suspicious_this_frame = False

        if res.boxes is not None:
            for box in res.boxes:
                cls = int(box.cls[0])
                conf = float(box.conf[0])

                if cls == ANTI_FAKE and conf >= FAKE_CONF_TH:
                    fake_this_frame = True
                elif cls == ANTI_REAL and conf >= REAL_CONF_TH:
                    real_this_frame = True

        # ⭐ MỚI: không real cũng không fake → nghi ngờ
        if not fake_this_frame and not real_this_frame:
            suspicious_this_frame = True

        # ================= PUSH WINDOWS =================
        self.fake_frames.append(fake_this_frame)
        self.real_frames.append(real_this_frame)
        self.suspicious_frames.append(suspicious_this_frame)

        fake_ratio = sum(self.fake_frames) / len(self.fake_frames)
        real_ratio = sum(self.real_frames) / len(self.real_frames)
        suspicious_ratio = sum(self.suspicious_frames) / len(self.suspicious_frames)

        # ================= FACE IN ROI =================
        face_in_roi = True if self.arcface.get(roi) else False

        # ================= STATE MACHINE =================
        if self.state == "IDLE":
            if (
                face_in_roi
                and fake_ratio < FAKE_RATIO_TH_ANTI
                and real_ratio >= REAL_RATIO_TH_ANTI
                and suspicious_ratio < SUSPICIOUS_RATIO_TH
            ):
                self.state = "ANTI"
                self.fake_frames.clear()
                self.real_frames.clear()
                self.suspicious_frames.clear()

        elif self.state == "ANTI":
            if fake_ratio >= FAKE_RATIO_TH_ANTI or suspicious_ratio >= SUSPICIOUS_RATIO_TH:
                # FAIL -> log 1 dòng
                self.log_presentation(
                    score_bona=real_ratio,
                    real_ratio=real_ratio,
                    fake_ratio=fake_ratio,
                    sus_ratio=suspicious_ratio,
                    state_end="ANTI_FAIL"
                )
                self.reset()
                self.fake_cooldown_until = now + 1.0

            elif len(self.fake_frames) == ANTI_WINDOW:
                # OK -> log 1 dòng
                self.log_presentation(
                    score_bona=real_ratio,
                    real_ratio=real_ratio,
                    fake_ratio=fake_ratio,
                    sus_ratio=suspicious_ratio,
                    state_end="ANTI_OK"
                )
                self.state = "FACEID"
                self.face_frames.clear()

        elif self.state == "FACEID":
            if fake_this_frame or suspicious_this_frame:
                if self.faceid_fake_since is None:
                    self.faceid_fake_since = now
                elif now - self.faceid_fake_since >= 0.5:
                    self.log_presentation(real_ratio, real_ratio, fake_ratio, suspicious_ratio, state_end="ANTI_FAIL")
                    self.reset()
                    self.fake_cooldown_until = now + 1.5
                    self.faceid_fake_since = None
                    return frame
            else:
                self.faceid_fake_since = None

            name = self.recognize(roi)
            self.face_frames.append(name)

            if len(self.face_frames) == FACE_WINDOW:
                most = max(set(self.face_frames), key=self.face_frames.count)
                ratio = self.face_frames.count(most) / FACE_WINDOW

                if most and ratio >= 0.8:
                    self.pending_attendance = {
                        "name": most,
                        "date": time.strftime("%Y-%m-%d"),
                        "time": time.strftime("%H:%M:%S"),
                        "terminal": "K-04"
                    }
                    self.state = "SUCCESS"
                    self.show_name_until = now + 999
                else:
                    self.reset()

        elif self.state == "SUCCESS":
            if now > self.show_name_until:
                self.reset()

        # ================= DEBUG OVERLAY =================
        cv2.putText(
            frame,
            f"REAL:{real_ratio:.2f} FAKE:{fake_ratio:.2f} SUS:{suspicious_ratio:.2f}",
            (20, 70),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"STATE: {self.state}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 0),
            2
        )

        return frame
